HELP_1 = """<b><u>ᴀᴅᴍɪɴ ᴋᴏᴍᴜᴛʟᴀʀı :</b></u>

╰☞ /durdur /pause - Akışı duraklatır.
╰☞ /devam /resume - Akışı devam ettirir.
╰☞ /son - /end - Akışı Sonlandırır.
╰☞ /atla /skip - Diğer parça ya atlar.
╰☞ /ileri - Oynatılan parçayı ileri alır.
╰☞ /gerial - Oynatılan parçayı geri alır.
╰☞ /karistir /suffle- Sıraya alınan Parçaları karışık oynatır.
╰☞ /tekrarla /loop - oynatılan parçayı istediğiniz kadar tekrar eder.
╰☞ /reload - Admin Önbelleğini yeniler.
/reboot - Botu yeniden başlatır.
"""

HELP_2 = """
<b><u>ʏᴇᴛᴋɪʟᴇɴᴅɪʀᴍᴇ ᴋᴏᴍᴜᴛʟᴀʀı :</b></u>

ᴀᴜᴛʜ ᴜsᴇʀs ᴄᴀɴ ᴜsᴇ ᴀᴅᴍɪɴ ʀɪɢʜᴛs ɪɴ ᴛʜᴇ ʙᴏᴛ ᴡɪᴛʜᴏᴜᴛ ᴀᴅᴍɪɴ ʀɪɢʜᴛs ɪɴ ᴛʜᴇ ᴄʜᴀᴛ.

╰☞ /yetkiver /auth - Grubunuzda yetkisiz üyeye yetki vererek botu kullandırabilirsiz.
╰☞ /yetkial /unauth - Grubunuzdaki botu kullanan yetkisiz üyeden bot yetkisini alır.
╰☞ /yetikiliste /authuser - Grubunuzdaki botu kullanan yetkili listesini açar.
"""

HELP_3 = """
<b><u>REKLAM KOMUTLARI</u></b>
🔸/reklam [Mesaj veya Mesaja Cevap] - Herhangi bir mesajı Bot'un Sunulan Sohbetlerine yayınlayın.

<u>yayın seçenekleri:</u>
**-pin** : Bu, mesajınızı sabitleyecektir 
**-pinloud** : Bu, mesajınızı yüksek sesli bildirimle sabitleyecektir
**-user** : Bu, mesajınızı botunuzu başlatan kullanıcılara yayınlayacaktır.
**-assistant** : Bu, mesajınızı botunuzun asistan hesabından yayınlayacaktır.
**-nobot** : Bu, botunuzu mesaj yayınlamamaya zorlar

**Örnek:** `/reklam -user -assistant -pin MERHABA ` """

HELP_4 = """<u><b>ʙʟᴀᴄᴋʟɪsᴛ ᴋᴏᴍᴜᴛʟᴀʀı :</b></u> [ᴏɴʟʏ ғᴏʀ sᴜᴅᴏᴇʀs]

ʀᴇsᴛʀɪᴄᴛ sʜɪᴛ ᴄʜᴀᴛs ᴛᴏ ᴜsᴇ ᴏᴜʀ ᴘʀᴇᴄɪᴏᴜs ʙᴏᴛ.

/blacklistchat [SOHBET KİMLİĞİ] : BOT KULLANARAK SOHBETLERİ KARA LİSTE EDİN..
/whitelistchat [SOHBET KİMLİĞİ] : KARA LİSTELENEN SOHBETİ BEYAZ LİSTEYE ALIN..
/blacklistedchat : ᴋᴀʀᴀ ʟɪsᴛᴇʏᴇ ᴀʟıɴᴀɴ ɢʀᴜᴘʟᴀʀ.
"""

HELP_5 = """
<u><b>ʙʟᴏᴄᴋ ᴜsᴇʀs:</b></u> [ᴏɴʟʏ ғᴏʀ sᴜᴅᴏᴇʀs]

sᴛᴀʀᴛs ɪɢɴᴏʀɪɴɢ ᴛʜᴇ ʙʟᴀᴄᴋʟɪsᴛᴇᴅ ᴜsᴇʀ, sᴏ ᴛʜᴀᴛ ʜᴇ ᴄᴀɴ'ᴛ ᴜsᴇ ʙᴏᴛ ᴄᴏᴍᴍᴀɴᴅs.

🔸/block [Kullanıcı adı veya bir kullanıcıya yanıt] - Bir kullanıcının bot komutlarını kullanmasını engeller.
🔸/unblock [Kullanıcı adı veya bir kullanıcıya yanıt] - Bir kullanıcıyı Bot'un Engellenenler Listesinden çıkarın.
🔸/blocklist - Engellenen Kullanıcı Listelerini Kontrol Edin
"""

HELP_6 = """
<u><b>ᴄʜᴀɴɴᴇʟ ᴩʟᴀʏ ᴄᴏᴍᴍᴀɴᴅs:</b></u>

ʏᴏᴜ ᴄᴀɴ sᴛʀᴇᴀᴍ ᴀᴜᴅɪᴏ/ᴠɪᴅᴇᴏ ɪɴ ᴄʜᴀɴɴᴇʟ.

/cplay - /coynat: sᴛᴀʀᴛs sᴛʀᴇᴀᴍɪɴɢ ᴛʜᴇ ʀᴇǫᴜᴇsᴛᴇᴅ ᴀᴜᴅɪᴏ ᴛʀᴀᴄᴋ ᴏɴ ᴄʜᴀɴɴᴇʟ's ᴠɪᴅᴇᴏᴄʜᴀᴛ.
/cvplay - /cvoynat: sᴛᴀʀᴛs sᴛʀᴇᴀᴍɪɴɢ ᴛʜᴇ ʀᴇǫᴜᴇsᴛᴇᴅ ᴠɪᴅᴇᴏ ᴛʀᴀᴄᴋ ᴏɴ ᴄʜᴀɴɴᴇʟ's ᴠɪᴅᴇᴏᴄʜᴀᴛ.
/cplayforce or /cvplayforce : sᴛᴏᴩs ᴛʜᴇ ᴏɴɢᴏɪɴɢ sᴛʀᴇᴀᴍ ᴀɴᴅ sᴛᴀʀᴛs sᴛʀᴇᴀᴍɪɴɢ ᴛʜᴇ ʀᴇǫᴜᴇsᴛᴇᴅ ᴛʀᴀᴄᴋ.

/channelplay [ᴄʜᴀᴛ ᴜsᴇʀɴᴀᴍᴇ ᴏʀ ɪᴅ] ᴏʀ [ᴅɪsᴀʙʟᴇ] : ᴄᴏɴɴᴇᴄᴛ ᴄʜᴀɴɴᴇʟ ᴛᴏ ᴀ ɢʀᴏᴜᴩ ᴀɴᴅ sᴛᴀʀᴛs sᴛʀᴇᴀᴍɪɴɢ ᴛʀᴀᴄᴋs ʙʏ ᴛʜᴇ ʜᴇʟᴩ ᴏғ ᴄᴏᴍᴍᴀɴᴅs sᴇɴᴛ ɪɴ ɢʀᴏᴜᴩ.
"""

HELP_7 = """
<u><b>ɢʟᴏʙᴀʟ ʙᴀɴ ғᴇᴀᴛᴜʀᴇ</b></u> [ᴏɴʟʏ ғᴏʀ sᴜᴅᴏᴇʀs] :

🔸/gban [Kullanıcı adı veya bir kullanıcıya yanıt] - Botun sunduğu sohbetten bir kullanıcıyı Gban ve botunuzu kullanmasını engelleyin.
🔸/ungban [Kullanıcı adı veya bir kullanıcıya yanıt] - Bir kullanıcıyı Bot'un gbanlı Listesinden çıkarın ve onun botunuzu kullanmasına izin verin
🔸/gbannedusers - Gbanlı Kullanıcı Listelerini Kontrol Edin
"""

HELP_8 = """
<b><u>ʟᴏᴏᴘ sᴛʀᴇᴀᴍ :</b></u>

<b>sᴛᴀʀᴛs sᴛʀᴇᴀᴍɪɴɢ ᴛʜᴇ ᴏɴɢᴏɪɴɢ sᴛʀᴇᴀᴍ ɪɴ ʟᴏᴏᴘ</b>

/tekrar - /loop [enable/disable] : ᴇɴᴀʙʟᴇs/ᴅɪsᴀʙʟᴇs ᴛᴇᴋʀᴀʀʟᴀɴᴍᴀʏı ᴋᴀᴘᴀᴛıᴘ ᴀᴄ̧ᴀʙɪʟɪʀsɪɴ
/tekrar - /loop [1, 2, 3, ...] : ɢɪʀᴅɪɢ̆ɪɴɪᴢ ʀᴀᴋᴀᴍ ᴋᴀᴅᴀʀ ᴘᴀʀᴄ̧ᴀ ᴛᴇʀᴋᴀʀʟᴀɴıʀ
♨️🔸(örneğin: /döngü 4 - Parçayı 4 kez tekrarlar.)
"""

HELP_9 = """
<u><b>ᴍᴀɪɴᴛᴇɴᴀɴᴄᴇ ᴍᴏᴅᴇ</b></u> [ᴏɴʟʏ ғᴏʀ sᴜᴅᴏᴇʀs] :


🔸/reboot - Botunuzu yeniden başlatın. 
🔸/update - Botu Güncelle.
🔸/speedtest - Sunucu hızlarını kontrol edin
🔸/bakim [enable / disable] 
🔸/logger [enable / disable] - Bot, logger grubunda aranan sorguları günlüğe kaydeder.
🔸/get_log [Hat Sayısı] - Get log of your bot from heroku or vps. Works for both.
🔸/autoend [enable|disable] - Hiç kimse dinlemiyorsa 3 dakika sonra otomatik akışı sonlandır özelliğini etkinleştirin.

"""

HELP_10 = """
<b><u>ᴘɪɴɢ & sᴛᴀᴛs :</b></u>

/start : Müzik botunu başlatırᴛ.
/help : ɢᴇᴛ ʜᴇʟᴩ ᴍᴇɴᴜ ᴡɪᴛʜ ᴇxᴩʟᴀɴᴀᴛɪᴏɴ ᴏғ ᴄᴏᴍᴍᴀɴᴅs.
/ping : sʜᴏᴡs ᴛʜᴇ ᴩɪɴɢ ᴀɴᴅ sʏsᴛᴇᴍ sᴛᴀᴛs ᴏғ ᴛʜᴇ ʙᴏᴛ.
🔸/aktifses - Botta aktif sesli sohbetleri kontrol edin.
🔸/aktifvideo - Botta aktif görüntülü aramaları kontrol edin.
🔸/stats - Bot İstatistiklerini Kontrol Edin.

"""

HELP_11 = """
<u><b>ᴩʟᴀʏ ᴄᴏᴍᴍᴀɴᴅs :</b></u>

<b>v :</b> sᴛᴀɴᴅs ғᴏʀ ᴠɪᴅᴇᴏ ᴩʟᴀʏ.
<b>force :</b> sᴛᴀɴᴅs ғᴏʀ ғᴏʀᴄᴇ ᴩʟᴀʏ.

▪️ /voynat - Video Oynatır.
/oynat /voynat /play - /vplay : sᴛᴀʀᴛs sᴛʀᴇᴀᴍɪɴɢ ᴛʜᴇ ʀᴇǫᴜᴇsᴛᴇᴅ ᴛʀᴀᴄᴋ ᴏɴ ᴠɪᴅᴇᴏᴄʜᴀᴛ.
♨️🔸 /oynat komutu aynı zamanda canlı yayında destekler.(örnek: /oynat kralfm canlı)
/playforce ᴏʀ /vplayforce : Sesli sohbette çalınan parçayı durdurur ve sırayı bozmadan temizlemeden aranan parçayı anında çalmaya başlar.
"""

HELP_12 = """
<b><u>sʜᴜғғʟᴇ ᴏ̨ᴜᴇᴜᴇ :</b></u>

/kariştir - /shuffle : Sıradaki parçaları karışık oynatır.
/sira : Mevcut çalma lsitesini gösterir.
"""

HELP_13 = """
<b><u>sᴇᴇᴋ sᴛʀᴇᴀᴍ :</b></u>

/ileri [ᴅᴜʀᴀᴛɪᴏɴ ɪɴ sᴇᴄᴏɴᴅs] : şᴀʀᴋıʏı ʙᴇʟɪʀʟᴇᴅɪɢ̆ɪɴɪᴢ sᴜ̈ʀᴇ ᴋᴀᴅᴀʀ ɪʟᴇʀɪ ᴀʟıʀ,
♨️🔸(örneğin: /ileri 30 - parçayı 30 saniye ileri alır)
/geri [ᴅᴜʀᴀᴛɪᴏɴ ɪɴ sᴇᴄᴏɴᴅs] : şᴀʀᴋıʏı ʙᴇʟɪʀʟᴇᴅɪɢ̆ɪɴɪᴢ sᴜ̈ʀᴇ ᴋᴀᴅᴀʀ ɢᴇʀɪ ᴀʟıʀ
♨️🔸(örneğin: /geri 30 - parçayı 30 saniye geriye alır)
"""

HELP_14 = """
<b><u>sᴏɴɢ ᴅᴏᴡɴʟᴏᴀᴅ</b></u>

/indir-  - /indir [sᴏɴɢ ɴᴀᴍᴇ/ʏᴛ ᴜʀʟ] : ɪsᴛᴇᴅɪɢ̆ɪɴɪᴢ şᴀʀᴋıʏı ᴍᴘ𝟹 ᴏʟᴀʀᴀᴋ ɪɴᴅɪʀɪʀ.

"""

HELP_15 = """
<b><u>sᴘᴇᴇᴅ ᴄᴏᴍᴍᴀɴᴅs :</b></u>

ʏᴏᴜ ᴄᴀɴ ᴄᴏɴᴛʀᴏʟ ᴛʜᴇ ᴘʟᴀʏʙᴀᴄᴋ sᴘᴇᴇᴅ ᴏғ ᴛʜᴇ ᴏɴɢᴏɪɴɢ sᴛʀᴇᴀᴍ. [ᴀᴅᴍɪɴs ᴏɴʟʏ]

/speed or /playback : ɢʀᴜᴘᴛᴀ sᴇsʟɪᴅᴇ ᴄ̧ᴀʟᴀɴ şᴀʀᴋıʏı ʜıᴢʟᴀɴᴅıʀıʀ.
/cspeed or /cplayback : ᴋᴀɴᴀʟᴅᴀ sᴇsʟɪᴅᴇ ᴄ̧ᴀʟᴀɴ şᴀʀᴋıʏı ʜıᴢʟᴀɴᴅıʀıʀ.
"""
